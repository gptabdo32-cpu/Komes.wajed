# 🌴 منصة الخمس السياحية (Siyaha Al-Khums)

[![GitHub license](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/gptabdo32-cpu/siyaha-alkhums/blob/main/LICENSE)
[![Project Status](https://img.shields.io/badge/status-In%20Development-orange.svg)](https://github.com/gptabdo32-cpu/siyaha-alkhums)
[![Built with Node.js](https://img.shields.io/badge/Built%20with-Node.js-green.svg)](https://nodejs.org/)

---

## 🌟 نظرة عامة على المشروع

منصة الخمس السياحية هي مشروع ويب متكامل يهدف إلى أن يكون الدليل الرقمي الموثوق والشامل لمدينة الخمس الليبية ومحيطها، مع التركيز بشكل خاص على المواقع الأثرية مثل **لبدة الكبرى (Lepcis Magna)** والمناطق الطبيعية.

تم بناء المنصة على أساس **المخطط المعماري المفصل** (Architectural Blueprint) لضمان أعلى مستويات الكفاءة، الدقة الجغرافية (GIS)، والامتثال القانوني (التوطين).

## 🏛 الميزات الرئيسية

## 🗺 هيكلة المحتوى والصفحات

تتبع المنصة هيكلة واضحة ومفصلة لتقديم تجربة مستخدم شاملة، مقسمة إلى سبعة أقسام رئيسية (مستوحاة من المخطط المعماري):

| القسم الرئيسي | المجلد | الصفحات الفرعية | المحتوى والوظيفة الرئيسية |
| :--- | :--- | :--- | :--- |
| **I. الصفحة الرئيسية** | `/` | `index.html` | نقطة الدخول، شريط بحث موحد، بطاقات وصول سريع، خريطة تفاعلية مصغرة (GIS View). |
| **II. الرث والاسكتشاف** | `pages/exploration/` | `lepcis_magna.html` | صفحة مخصصة لموقع لبدة الكبرى (Mega-Page)، توليد مسار رحلة آلي. |
| | | `natural_sites.html` | قائمة بالمواقع الطبيعية (شواطئ، عيون طبيعية)، تصنيف حسب نوع النشاط (تخييم، سباحة). |
| | | `certified_guides.html` | ملفات شخصية للمرشدين المعتمدين، نظام تصفية حسب اللغة ورقم الترخيص. |
| **III. الضيافة والإقامة** | `pages/accommodation/` | `hotels.html` | قائمة بالفنادق والمنتجعات، عرض شارة "مُصرح به" ورقم ترخيص وزارة السياحة. |
| | | `rest_houses.html` | قائمة بالشاليهات والاستراحات، تصنيف حسب الخصائص (شاطئ خاص، مسبح). |
| **IV. المذاق والطعام** | `pages/dining/` | `restaurants.html` | قائمة بالمطاعم، تصفية حسب المطبخ (ليبي تقليدي، بحري)، عرض قائمة الطعام. |
| | | `cafes.html` | قائمة بالمقاهي والتجمعات، تصفية حسب الأجواء (هادئة، منطقة عمل). |
| | | `delivery.html` | قائمة محدثة بأرقام مندوبي التوصيل القريبين (Geo-Location). |
| **V. الخدمات والنقل** | `pages/transport/` | `car_rental.html` | عروض تأجير السيارات، متطلبات التأجير للسياح. |
| | | `stations.html` | تحديد محطات الحافلات ومواقف سيارات الأجرة الرئيسية. |
| | | `e_payment.html` | واجهة لدمج بوابة الدفع T-Lync والدفع عبر رصيد ليبيانا. |
| **VI. السلامة والرعاية الصحية** | `pages/safety/` | `hospitals.html` | قائمة بالمستشفيات والصيدليات، عرض ساعات العمل وربط الموقع بالخريطة (GIS). |
| | | `emergency_numbers.html` | قائمة بأرقام الطوارئ (إسعاف، شرطة، إطفاء)، زر اتصال مباشر (One-Tap Call). |
| **VII. المركز الشخصي والولاء** | `pages/profile/` | `dashboard.html` | لوحة تحكم المستخدم، إدارة الحجوزات والإشعارات، إعدادات اللغة. |
| | | `loyalty.html` | عرض نقاط الولاء (MyCred)، لوحة صدارة للمستخدمين الأكثر نشاطًا. |

## 🏛 الميزات الرئيسية

يعتمد المشروع على ثلاث ركائز أساسية مستوحاة من المخطط المعماري:

1.  **التخطيط الفوري المتقدم (Itinerary Generation):** أداة تخطيط مخصصة تولد مسارات رحلات ديناميكية ومخصصة بناءً على تفضيلات المستخدم والوقت المتاح.
2.  **الموثوقية المكانية (GIS Integration):** دمج نظام معلومات جغرافية (GIS) لضمان دقة المواقع والإحداثيات لكل نقطة اهتمام (POI) أو خدمة (فندق، مطعم، مرشد).
3.  **الشرعية والتوثيق (Verification):** بناء الثقة من خلال إلزام مزودي الخدمات بإضافة رقم ترخيص وزارة السياحة، وعرض شارة "مُصرح به" على الواجهة.
4.  **نظام الولاء والمكافآت (Gamification):** نظام MyCred لجمع النقاط ومكافأة المستخدمين الأكثر نشاطًا وحجزًا.
5.  **الدفع الإلكتروني الموطن:** دمج بوابة الدفع T-Lync لدعم حلول الدفع الموحدة والتسوية المالية.

## 🛠 الهيكلة المعمارية (Architecture)

يعتمد المشروع على بنية **MVC (Model-View-Controller)** مع فصل واضح للخدمات (Services) لضمان قابلية التوسع والصيانة.

| المجلد | الوصف | الملفات الرئيسية |
| :--- | :--- | :--- |
| `controllers/` | منطق التحكم الذي يعالج طلبات المستخدمين ويتفاعل مع النماذج والخدمات. | `authController.js`, `myCredController.js`, `paymentController.js` |
| `models/` | تعريف نماذج البيانات (Schemas) الخاصة بالخدمات ونقاط الاهتمام ونظام الولاء. | `poiSchema.js`, `serviceSchema.js`, `loyaltySchema.js` |
| `routes/` | تعريف مسارات API التي تربط بين طلبات المستخدمين ووحدات التحكم. | `api.js` |
| `services/` | وحدات برمجية منفصلة للتعامل مع الخدمات الخارجية والمنطق المعقد (GIS، الدفع). | `payment_api.js`, `gisService.js` |
| `pages/` | ملفات HTML للواجهة الأمامية، منظمة حسب أقسام الموقع الرئيسية. | `exploration/`, `accommodation/`, `dining/`, `transport/`, `safety/`, `profile/` |
| `scripts/` | ملفات JavaScript للواجهة الأمامية (منطق العميل). | `main_core.js`, `map_interactions.js`, `user_preferences.js` |
| `styles/` | ملفات CSS للتنسيق. | `main.css` |
| `config.js` | ملف إعدادات المشروع والمتغيرات البيئية (API Keys, Database URI). | `config.js` |
| `server.js` | نقطة الدخول الرئيسية لتشغيل الخادم (Node.js/Express). | `server.js` |

## 🚀 بدء التشغيل

لإعداد وتشغيل المشروع محليًا، اتبع الخطوات التالية:

### المتطلبات الأساسية

*   [Node.js](https://nodejs.org/) (يفضل الإصدار 18 أو أحدث)
*   [npm](https://www.npmjs.com/) (يأتي مع Node.js)

### الإعداد

1.  **استنساخ المستودع:**
    ```bash
    git clone https://github.com/gptabdo32-cpu/siyaha-alkhums.git
    cd siyaha-alkhums
    ```

2.  **تثبيت التبعيات:**
    ```bash
    npm install
    ```

3.  **إعداد ملف الإعدادات:**
    قم بإنشاء ملف `.env` في جذر المشروع (أو املأ `config.js` مباشرة) وأضف متغيرات البيئة اللازمة:
    ```javascript
    // config.js (مثال)
    module.exports = {
        PORT: process.env.PORT || 3000,
        DATABASE_URI: "mongodb://localhost:27017/siyaha_db",
        GIS_API_KEY: "YOUR_GIS_PROVIDER_API_KEY",
        TLYNC_SECRET: "YOUR_TLYNC_PAYMENT_SECRET"
    };
    ```

4.  **تشغيل الخادم:**
    ```bash
    node server.js
    # أو باستخدام nodemon للتطوير:
    # npm install -g nodemon
    # nodemon server.js
    ```

5.  **الوصول إلى التطبيق:**
    افتح متصفحك وتوجه إلى: `http://localhost:3000`

## 🤝 المساهمة

نرحب بالمساهمات لتحسين منصة الخمس السياحية. إذا كان لديك اقتراح أو وجدت خطأ، يرجى اتباع الخطوات التالية:

1.  قم بعمل تفرع (Fork) للمستودع.
2.  أنشئ فرعًا جديدًا للميزة الخاصة بك (`git checkout -b feature/AmazingFeature`).
3.  قم بتنفيذ التغييرات والالتزام بها (`git commit -m 'Add some AmazingFeature'`).
4.  ادفع التغييرات إلى الفرع (`git push origin feature/AmazingFeature`).
5.  افتح طلب سحب (Pull Request).

## 📜 الترخيص

هذا المشروع مرخص بموجب ترخيص MIT. انظر ملف [LICENSE](https://github.com/gptabdo32-cpu/siyaha-alkhums/blob/main/LICENSE) لمزيد من التفاصيل.

## 📧 التواصل

إذا كان لديك أي استفسارات، يمكنك التواصل مع مالك المستودع عبر GitHub.

**المطور:** gptabdo32-cpu
**رابط المستودع:** [https://github.com/gptabdo32-cpu/siyaha-alkhums](https://github.com/gptabdo32-cpu/siyaha-alkhums)
